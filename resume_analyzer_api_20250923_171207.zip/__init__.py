"""
Resume Analyzer REST API Application Package
"""
__version__ = "1.0.0"
